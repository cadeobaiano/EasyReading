// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDqWbHQ8l8KeueAVzrBW7p6DvfESVY5MMI",
  projectId: "easyreading-a2bde",
  authDomain: "easyreading-a2bde.firebaseapp.com",
  storageBucket: "easyreading-a2bde.appspot.com",
  messagingSenderId: "662523299244",
  appId: "1:662523299244:web:YOUR_WEB_APP_ID", // Você precisará adicionar o appId específico da web
  measurementId: "G-MEASUREMENT_ID" // Opcional: para Analytics
};

module.exports = firebaseConfig;
